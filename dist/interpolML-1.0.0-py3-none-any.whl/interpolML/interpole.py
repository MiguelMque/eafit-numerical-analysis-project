import pandas as pd


class Interpolation:

    def __init__(self, data : pd.DataFrame):

        self.data = data



    def newton_interpolation(self):




        return


    def rapson_interpolation(self):
        return