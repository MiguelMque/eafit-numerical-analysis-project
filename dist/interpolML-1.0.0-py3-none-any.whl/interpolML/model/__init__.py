from interpolML.model.model import Model
