from interpolML.model import Model
from orbit.models.dlt import DLTFull


class Orbit(Model):

    def __new__(cls, freq:str) -> Model:
        model = cls._build_model()
        name = "orbit"
        return Model(name=name, model=model, freq=freq)

    @classmethod
    def _build_model(cls):
        model = DLTFull(
            response_col='y', date_col='ds',
            seasonality=52,
        )

        return model
