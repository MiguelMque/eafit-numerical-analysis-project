
from interpolML import Model
class NeuralProphet(Model):
    """Constructor class to build a Neural Prophet model.

    """

    def __new__(cls, name: str) -> Model:
        return

