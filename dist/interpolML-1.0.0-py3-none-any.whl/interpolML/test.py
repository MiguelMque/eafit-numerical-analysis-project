#%%
#%%

from interpol import interpolML

test_object = interpolML("2019-01-01", "2021-01-01", "2021-03-31")

#%%
test_object.data
#%%

